Book Recommendation Engine by Whale's Well

** We have initialized books in this program only 23 books as it is a
demo version.
** In registration, we did not force user's input, so user can type 
anything she want, we are not sure that this will cause bug or not.

*************************************************************************
Book Recommendation Engine Manual

.+. Please run EngineUI as the main method of this program
.+. You have to register first so you can login to the program
.+. After login, system will show menu page. Please type the number of 
	each menu to get that action from system.
.+. To buy book, you can buy from 4 ways as the first four menu. Please
	select the index of the book that you want to look for detail, 
	and type Y to buy it. 
.+. You have to buy any book to get both content-based and community-based 
	book suggestion from system, because system may not have reference 
	book.